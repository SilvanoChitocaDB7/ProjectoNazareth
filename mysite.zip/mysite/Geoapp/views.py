from django.shortcuts import render
from django.http import HttpResponse
from os import name
import folium
from folium.plugins import MarkerCluster
from folium.plugins import LocateControl
from folium.plugins import MiniMap
from folium.plugins import Fullscreen
from folium.plugins import ScrollZoomToggler
#from folium.plugins import Geocoder
from folium.plugins import Terminator
from folium.plugins import AntPath 
from branca.element import Template, MacroElement
from .models import atm
from folium.plugins import Draw

# Create your views here.

def index(request):

    caixa = atm.objects.all()
    m = folium.Map(location=[-8.829120973774515, 13.264365610225981],name="Geolocalização", zoom_start=16, max_bounds = True)
    marker_cluster = MarkerCluster(name="Com dinheiro").add_to(m)
    marker_cluster1 = MarkerCluster(name="Sem sistema").add_to(m)
    marker_cluster2 = MarkerCluster(name="Com papel").add_to(m)
    draw = Draw(export=True)
    draw.add_to(m)

    for valor in caixa:

        if valor.dinheiro:
            coordenadas = (valor.latitude, valor.longitude)
            print(coordenadas)
            folium.Marker(coordenadas, popup=valor.Nome, icon=folium.Icon(color="green")).add_to(marker_cluster)

        if valor.sistema:
            coordenadas = (valor.latitude, valor.longitude)
            print(coordenadas)
            folium.Marker(coordenadas, popup=valor.Nome, icon=folium.Icon(color="orange")).add_to(marker_cluster1)
            
        if not valor.sistema:
            coordenadas = (valor.latitude, valor.longitude)
            print(coordenadas)
            folium.Marker(coordenadas, popup=valor.Nome, icon=folium.Icon(color="red")).add_to(marker_cluster1)

        if valor.papel:
            coordenadas = (valor.latitude, valor.longitude)
            print(coordenadas)
            folium.Marker(coordenadas, popup=valor.Nome, icon=folium.Icon(color="yellow")).add_to(marker_cluster2)


    Fullscreen().add_to(m)
    ScrollZoomToggler().add_to(m)
    folium.LatLngPopup().add_to(m)
    folium.LayerControl().add_to(m)
    

    
    #Geocoder().add_to(m)
    #Terminator().add_to(m)

    template = """
    {% macro html(this, kwargs) %}

    <!doctype html>
    <html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema de geolocalização de ATM gerenciado pela Emis</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    <script>
    $( function() {
        $( "#maplegend" ).draggable({
                        start: function (event, ui) {
                            $(this).css({
                                right: "auto",
                                top: "auto",
                                bottom: "auto"
                            });
                        }
                    });
    });

    </script>
    </head>
    <body>

    <div id='maplegend' class='maplegend' 
        style='position: absolute; z-index:9999; border:2px solid grey; background-color:rgba(255, 255, 255, 0.8);
        border-radius:6px; padding: 10px; font-size:14px; right: 20px; bottom: 20px;'>
        
    <div class='legend-title'>Estado dos Multicaixa</div>
    <div class='legend-scale'>
    <ul class='legend-labels'>
        <li><span style='background:green;opacity:0.7;'></span>Com dinheiro</li>
        <li><span style='background:orange;opacity:0.7;'></span>Com sistema</li>
        <li><span style='background:yellow;opacity:0.7;'></span>Com papel</li>
        <li><span style='background:red;opacity:0.7;'></span>Sem sistema</li>

    </ul>
    </div>
    </div>
    
    </body>
    </html>

    <style type='text/css'>
    .maplegend .legend-title {
        text-align: left;
        margin-bottom: 5px;
        font-weight: bold;
        font-size: 90%;
        }
    .maplegend .legend-scale ul {
        margin: 0;
        margin-bottom: 5px;
        padding: 0;
        float: left;
        list-style: none;
        }
    .maplegend .legend-scale ul li {
        font-size: 80%;
        list-style: none;
        margin-left: 0;
        line-height: 18px;
        margin-bottom: 2px;
        }
    .maplegend ul.legend-labels li span {
        display: block;
        float: left;
        height: 16px;
        width: 30px;
        margin-right: 5px;
        margin-left: 0;
        border: 1px solid #999;
        }
    .maplegend .legend-source {
        font-size: 80%;
        color: #777;
        clear: both;
        }
    .maplegend a {
        color: #777;
        }
    </style>
    {% endmacro %}"""

    macro = MacroElement()
    macro._template = Template(template)

    m.get_root().add_child(macro)

    #para adicionar no objecto do mapa para controlar a forma como se movimenta
    #dragging=False
    #zoom_control=False, scrollWheelZoom=False,

    LocateControl(keepCurrentZoomLevel = True, strings={"title":"localização actual", "popup":"Localização actual"}).add_to(m)
    minimap = MiniMap()

    #a linha abaixo adiciona o minimap no site
    #m.add_child(minimap)
    caminho=[(-8.82639015645168, 13.244673127803168),(-8.824989528032546, 13.245381833307448),
            (-8.82019103852356, 13.24645801573945),(-8.816507831299106, 13.247612943227466), 
		    (-8.816819089668556, 13.253308835612728),(-8.816378140233766,13.256852363132879),
		    (-8.816066881492858,13.26596054127856),(-8.815950344873926,13.271742000698822),
		    (-8.818806302153405,13.27240594553632),(-8.822318327447164,13.27279650132391),
		    (-8.832699833177088, 13.273851001949055),(-8.841035700562244, 13.274788335837997),
		    (-8.843428368402158, 13.274866446994906),(-8.840456826975469, 13.269047165768),(-8.83733089389105, 13.261392272342391),
		    (-8.835787213451226, 13.259361382250603),(-8.83509255514383, 13.257447658895046),(-8.830847392602905, 13.250378599149997),
		    (-8.827759970970035, 13.245340429496707,),(-8.82698811152477, 13.244481206766181),(-8.82633202972589, 13.244754595816119)]
    caminho2=[(-8.831932125238524,13.263278229263676), (-8.829166657221947, 13.26455326811461),(-8.829198496609479, 13.264626916568773)]
    caminho3=[(-8.831204066112093,13.268007619370792), (-8.830385334091645, 13.267228903501206),(-8.830299151668001, 13.26735349804079),
    	    (-8.830243748671379,13.26732234940539)]

    folium.Circle(location=[-8.8219,13.2701], popup='Zona A', fill_color='#000', radius=300, weight=0.2, color="#000").add_to(m)
    folium.Circle(location=[-8.8305,13.2635], popup='Banco Millenium tem valores', fill_color='#000', radius=600, weight=0.2, color="#000").add_to(m)
    folium.Circle(location=[-8.8364,13.2704], popup='Zona C', fill_color='#000', radius=600, weight=0.2, color="#000").add_to(m)

    AntPath(caminho, delay=400, weight=3, color="red", dash_array=[30,15]).add_to(m)
    AntPath(caminho2, delay=400, weight=3, color="blue", dash_array=[30,15]).add_to(m)
    AntPath(caminho3, delay=400, weight=3, color="blue", dash_array=[30,15]).add_to(m)

    
        
    context = {
    'mapa': m._repr_html_(),
    'id': "",
	'data': "",
	'Email': ""

    }
    return render(request, 'blank-page.html', context)
