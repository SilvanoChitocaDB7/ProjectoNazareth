from django.contrib import admin
from .models import atm, usuario, banco


class VerAtmAdmin(admin.ModelAdmin):
    list_filter = ['id','Nome','latitude','longitude', 'dinheiro', 'papel', 'sistema'] 
    search_fields =['id','Nome','latitude','longitude', 'dinheiro', 'papel', 'sistema'] 
    actions = ["export_as_csv"]
    list_display = ['id','Nome','latitude','longitude', 'dinheiro', 'papel', 'sistema'] 
    empty_value_display = 'Sem valor '
    list_display_links = ['id','Nome']
    list_per_page = 15
    
  


admin.site.register(atm, VerAtmAdmin)
admin.site.register(usuario)
admin.site.register(banco)
# Register your models here.

