from django.db import models
from django.contrib.auth.models import AbstractUser


class banco(models.Model):
    Nome = models.CharField(max_length=30)

class usuario(models.Model):
    primeiro_nome = models.CharField(max_length=30)
    ultimo_nome = models.CharField(max_length=30)


class atm(models.Model):
    Nome = models.CharField(max_length=30)
    latitude = models.FloatField(default=1)
    longitude = models.FloatField(default=1)
    dinheiro = models.BooleanField(default=False)
    papel = models.BooleanField(default=False)
    sistema = models.BooleanField(default=False)
    banco = models.ForeignKey(banco, on_delete=models.CASCADE, default=None)
    
    def __str__(self):
        return self.Nome


class funcionario(models.Model):
    Nome = models.CharField(max_length=30)
    Senha = models.CharField(max_length=30)
    banco = models.ForeignKey(banco, on_delete=models.CASCADE, default=None)

    def __str__(self):
        return self.Nome
